package com.example.recuperacion

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Error
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditContactScreen(contactId: Int, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var currentImageUrl by remember { mutableStateOf<String?>(null) }
    var newImageUri by remember { mutableStateOf<Uri?>(null) }
    var isLoading by remember { mutableStateOf(true) }

    var nameError by remember { mutableStateOf(false) }
    var phoneError by remember { mutableStateOf(false) }
    var emailError by remember { mutableStateOf(false) }

    LaunchedEffect(contactId) {
        try {
            val contact = RetrofitClient.api.getContact(contactId)
            name = contact.name; phone = contact.phone ?: ""; email = contact.email ?: ""
            currentImageUrl = contact.image?.url?.let { url ->
                if (url.contains("127.0.0.1")) url.replace("127.0.0.1", "10.0.2.2")
                else if (url.startsWith("http")) url else "http://10.0.2.2:8000$url"
            }
        } catch (e: Exception) { Toast.makeText(context, "Error cargando datos", Toast.LENGTH_SHORT).show() }
        finally { isLoading = false }
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { newImageUri = it }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Editar Contacto") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Volver") } }) }
    ) { padding ->
        if (isLoading) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        else Column(modifier = Modifier.padding(padding).padding(16.dp).fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(modifier = Modifier.size(120.dp).clip(CircleShape).background(Color.LightGray).clickable { imagePicker.launch("image/*") }, contentAlignment = Alignment.Center) {
                if (newImageUri != null) AsyncImage(model = newImageUri, null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else AsyncImage(model = currentImageUrl ?: "https://ui-avatars.com/api/?name=$name", null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            }
            Spacer(Modifier.height(24.dp))

            // NOMBRE
            OutlinedTextField(
                value = name,
                onValueChange = { name = it; nameError = false },
                label = { Text("Nombre") },
                modifier = Modifier.fillMaxWidth(),
                isError = nameError,
                trailingIcon = { if (nameError) Icon(Icons.Filled.Error, null, tint = MaterialTheme.colorScheme.error) },
                supportingText = { if (nameError) Text("Campo vacío", Modifier.fillMaxWidth(), textAlign = TextAlign.End, color = MaterialTheme.colorScheme.error) }
            )
            Spacer(Modifier.height(8.dp))

            // TELÉFONO (MÁXIMO 10 DÍGITOS)
            OutlinedTextField(
                value = phone,
                onValueChange = { input ->
                    if (input.all { it.isDigit() } && input.length <= 10) {
                        phone = input
                        phoneError = false
                    }
                },
                label = { Text("Teléfono") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                isError = phoneError,
                trailingIcon = { if (phoneError) Icon(Icons.Filled.Error, null, tint = MaterialTheme.colorScheme.error) },
                supportingText = { if (phoneError) Text("Campo vacío", Modifier.fillMaxWidth(), textAlign = TextAlign.End, color = MaterialTheme.colorScheme.error) }
            )
            Spacer(Modifier.height(8.dp))

            // EMAIL
            OutlinedTextField(
                value = email,
                onValueChange = { email = it; emailError = false },
                label = { Text("Email") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                isError = emailError,
                trailingIcon = { if (emailError) Icon(Icons.Filled.Error, null, tint = MaterialTheme.colorScheme.error) },
                supportingText = { if (emailError) Text("Campo vacío", Modifier.fillMaxWidth(), textAlign = TextAlign.End, color = MaterialTheme.colorScheme.error) }
            )
            Spacer(Modifier.height(24.dp))

            Button(
                onClick = {
                    var hasError = false
                    if (name.isBlank()) { nameError = true; hasError = true }
                    if (phone.isBlank()) { phoneError = true; hasError = true }
                    if (email.isBlank()) { emailError = true; hasError = true }
                    if (hasError) return@Button

                    isLoading = true
                    val method = "PUT".toRequestBody("text/plain".toMediaTypeOrNull())
                    val namePart = name.toRequestBody("text/plain".toMediaTypeOrNull())
                    val phonePart = phone.toRequestBody("text/plain".toMediaTypeOrNull())
                    val emailPart = email.toRequestBody("text/plain".toMediaTypeOrNull())
                    val imagePart = newImageUri?.let { uri ->
                        val file = getFileFromUriEdit(context, uri)
                        val reqFile = file.asRequestBody("image/*".toMediaTypeOrNull())
                        MultipartBody.Part.createFormData("image", file.name, reqFile)
                    }
                    scope.launch {
                        try {
                            RetrofitClient.api.updateContact(contactId, method, namePart, phonePart, emailPart, imagePart)
                            Toast.makeText(context, "Actualizado correctamente", Toast.LENGTH_SHORT).show()
                            onBack()
                        } catch (e: Exception) { Toast.makeText(context, "Error al actualizar", Toast.LENGTH_SHORT).show() }
                        finally { isLoading = false }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(50.dp), enabled = !isLoading
            ) { Text("GUARDAR CAMBIOS") }
        }
    }
}

fun getFileFromUriEdit(context: Context, uri: Uri): File {
    val tempFile = File(context.cacheDir, "temp_image_edit.jpg")
    context.contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(tempFile).use { output -> input.copyTo(output) } }
    return tempFile
}