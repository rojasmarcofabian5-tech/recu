package com.example.recuperacion

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val navController = rememberNavController()

            NavHost(navController = navController, startDestination = "list") {
                // 1. LISTA
                composable("list") {
                    ContactListScreen(
                        onFabClick = { navController.navigate("create") },
                        onContactClick = { id -> navController.navigate("detail/$id") }
                    )
                }
                // 2. CREAR
                composable("create") {
                    CreateContactScreen(onBack = { navController.popBackStack() })
                }
                // 3. DETALLE
                composable(
                    route = "detail/{contactId}",
                    arguments = listOf(navArgument("contactId") { type = NavType.IntType })
                ) { backStackEntry ->
                    val id = backStackEntry.arguments?.getInt("contactId") ?: 0
                    ContactDetailScreen(
                        contactId = id,
                        onBack = { navController.popBackStack() },
                        onEditClick = { navController.navigate("edit/$id") }
                    )
                }
                // 4. EDITAR
                composable(
                    route = "edit/{contactId}",
                    arguments = listOf(navArgument("contactId") { type = NavType.IntType })
                ) { backStackEntry ->
                    val id = backStackEntry.arguments?.getInt("contactId") ?: 0
                    EditContactScreen(
                        contactId = id,
                        onBack = { navController.popBackStack() }
                    )
                }
            }
        }
    }
}