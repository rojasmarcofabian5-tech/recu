package com.example.recuperacion

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactListScreen(
    onFabClick: () -> Unit,
    onContactClick: (Int) -> Unit
) {
    var contacts by remember { mutableStateOf<List<Contact>>(emptyList()) }
    var searchText by remember { mutableStateOf("") }

    // Cargar siempre que se muestre
    LaunchedEffect(Unit) {
        try { contacts = RetrofitClient.api.getContacts() } catch (e: Exception) { e.printStackTrace() }
    }

    val filteredContacts = contacts.filter { it.name.contains(searchText, ignoreCase = true) }
    val groupedContacts = if (filteredContacts.isNotEmpty()) filteredContacts.groupBy { it.name.first().uppercase() } else emptyMap()

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = onFabClick, containerColor = Color(0xFF2962FF), contentColor = Color.White) {
                Icon(Icons.Default.Add, contentDescription = "Nuevo")
            }
        }
    ) { paddingValues ->
        Column(modifier = Modifier.padding(paddingValues).fillMaxSize().padding(16.dp)) {
            Text("Contactos", fontSize = 32.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 16.dp))
            TextField(
                value = searchText, onValueChange = { searchText = it },
                placeholder = { Text("Buscar") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp).clip(RoundedCornerShape(12.dp)),
                colors = TextFieldDefaults.colors(focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent)
            )
            LazyColumn {
                groupedContacts.forEach { (initial, list) ->
                    item { Text(initial, fontSize = 18.sp, color = Color.Gray, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 8.dp)) }
                    items(list) { contact -> ContactItem(contact, onClick = { onContactClick(contact.id) }) }
                }
            }
        }
    }
}

@Composable
fun ContactItem(contact: Contact, onClick: () -> Unit) {
    val imageUrl = contact.image?.url?.let { url ->
        if (url.contains("127.0.0.1")) url.replace("127.0.0.1", "10.0.2.2")
        else if (url.startsWith("http")) url
        else "http://10.0.2.2:8000$url"
    }
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp).clickable { onClick() }, verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(
            model = imageUrl ?: "https://ui-avatars.com/api/?name=${contact.name}",
            contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.size(50.dp).clip(CircleShape).background(Color.LightGray)
        )
        Spacer(Modifier.width(16.dp))
        Column {
            Text(contact.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(contact.email ?: contact.phone ?: "", color = Color.Gray, fontSize = 14.sp)
        }
    }
}