package com.example.recuperacion

import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*

// --- MODELOS ---
data class Contact(
    val id: Int,
    val name: String,
    val phone: String?,
    val email: String?,
    val image: ImageModel?
)

data class ImageModel(
    val id: Int,
    val url: String
)

// --- INTERFAZ API ---
interface ApiService {
    // 1. LISTA
    @GET("api/contacts")
    suspend fun getContacts(): List<Contact>

    // 2. DETALLE
    @GET("api/contacts/{id}")
    suspend fun getContact(@Path("id") id: Int): Contact

    // 3. CREAR
    @Multipart
    @POST("api/contacts")
    suspend fun createContact(
        @Part("name") name: RequestBody,
        @Part("phone") phone: RequestBody?,
        @Part("email") email: RequestBody?,
        @Part image: MultipartBody.Part?
    ): Contact

    // 4. EDITAR (Truco para Laravel: Se usa POST pero enviamos "_method" = "PUT")
    @Multipart
    @POST("api/contacts/{id}")
    suspend fun updateContact(
        @Path("id") id: Int,
        @Part("_method") method: RequestBody,
        @Part("name") name: RequestBody,
        @Part("phone") phone: RequestBody?,
        @Part("email") email: RequestBody?,
        @Part image: MultipartBody.Part?
    ): Contact

    // 5. ELIMINAR
    @DELETE("api/contacts/{id}")
    suspend fun deleteContact(@Path("id") id: Int): retrofit2.Response<Unit>
}

// --- CLIENTE RETROFIT ---
object RetrofitClient {
    private const val BASE_URL = "http://10.0.2.2:8000/" // IP mágica para emulador

    val api: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}