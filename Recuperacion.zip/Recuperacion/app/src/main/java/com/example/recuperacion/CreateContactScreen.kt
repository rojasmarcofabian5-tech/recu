package com.example.recuperacion

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Error
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import okhttp3.MultipartBody

// --- ¡AQUÍ ESTÁ LA SOLUCIÓN! ESTOS SON LOS 3 IMPORTS OBLIGATORIOS ---
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.asRequestBody // <--- ESTE FALTABA
import okhttp3.RequestBody.Companion.toRequestBody
// --------------------------------------------------------------------

import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateContactScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    // Variables de error
    var nameError by remember { mutableStateOf(false) }
    var phoneError by remember { mutableStateOf(false) }
    var emailError by remember { mutableStateOf(false) }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { imageUri = it }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Nuevo Contacto") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Volver") } }) }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).padding(16.dp).fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(modifier = Modifier.size(120.dp).clip(CircleShape).background(Color.LightGray).clickable { imagePicker.launch("image/*") }, contentAlignment = Alignment.Center) {
                if (imageUri != null) AsyncImage(model = imageUri, null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else Icon(Icons.Default.CameraAlt, null, tint = Color.Gray)
            }
            Spacer(Modifier.height(24.dp))

            // NOMBRE
            OutlinedTextField(
                value = name,
                onValueChange = { name = it; nameError = false },
                label = { Text("Nombre") },
                modifier = Modifier.fillMaxWidth(),
                isError = nameError,
                trailingIcon = { if (nameError) Icon(Icons.Filled.Error, null, tint = MaterialTheme.colorScheme.error) },
                supportingText = { if (nameError) Text("Campo vacío", Modifier.fillMaxWidth(), textAlign = TextAlign.End, color = MaterialTheme.colorScheme.error) }
            )
            Spacer(Modifier.height(8.dp))

            // TELÉFONO
            OutlinedTextField(
                value = phone,
                onValueChange = { input ->
                    if (input.all { it.isDigit() } && input.length <= 10) {
                        phone = input
                        phoneError = false
                    }
                },
                label = { Text("Teléfono") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                isError = phoneError,
                trailingIcon = { if (phoneError) Icon(Icons.Filled.Error, null, tint = MaterialTheme.colorScheme.error) },
                supportingText = { if (phoneError) Text("Campo vacío", Modifier.fillMaxWidth(), textAlign = TextAlign.End, color = MaterialTheme.colorScheme.error) }
            )
            Spacer(Modifier.height(8.dp))

            // EMAIL
            OutlinedTextField(
                value = email,
                onValueChange = { email = it; emailError = false },
                label = { Text("Email") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                isError = emailError,
                trailingIcon = { if (emailError) Icon(Icons.Filled.Error, null, tint = MaterialTheme.colorScheme.error) },
                supportingText = { if (emailError) Text("Campo vacío", Modifier.fillMaxWidth(), textAlign = TextAlign.End, color = MaterialTheme.colorScheme.error) }
            )

            Spacer(Modifier.height(24.dp))

            Button(
                onClick = {
                    var hasError = false
                    if (name.isBlank()) { nameError = true; hasError = true }
                    if (phone.isBlank()) { phoneError = true; hasError = true }
                    if (email.isBlank()) { emailError = true; hasError = true }
                    if (hasError) return@Button

                    isLoading = true

                    // PREPARAR DATOS
                    val namePart = name.toRequestBody("text/plain".toMediaTypeOrNull())
                    val phonePart = phone.toRequestBody("text/plain".toMediaTypeOrNull())
                    val emailPart = email.toRequestBody("text/plain".toMediaTypeOrNull())

                    val imagePart = imageUri?.let { uri ->
                        val file = getFileFromUriCreate(context, uri)
                        // AQUÍ ES DONDE DABA EL ERROR, AHORA YA FUNCIONARÁ
                        val reqFile = file.asRequestBody("image/*".toMediaTypeOrNull())
                        MultipartBody.Part.createFormData("image", file.name, reqFile)
                    }

                    scope.launch {
                        try {
                            RetrofitClient.api.createContact(namePart, phonePart, emailPart, imagePart)
                            Toast.makeText(context, "Guardado exitosamente", Toast.LENGTH_SHORT).show()
                            onBack()
                        } catch (e: Exception) { Toast.makeText(context, "Error al guardar", Toast.LENGTH_SHORT).show() }
                        finally { isLoading = false }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(50.dp), enabled = !isLoading
            ) { Text("GUARDAR") }
        }
    }
}

fun getFileFromUriCreate(context: Context, uri: Uri): File {
    val tempFile = File(context.cacheDir, "temp_image_create.jpg")
    context.contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(tempFile).use { output -> input.copyTo(output) } }
    return tempFile
}