package com.example.recuperacion

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBackIosNew
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactDetailScreen(
    contactId: Int,
    onBack: () -> Unit,
    onEditClick: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    var contact by remember { mutableStateOf<Contact?>(null) }

    LaunchedEffect(contactId) {
        try { contact = RetrofitClient.api.getContact(contactId) } catch (e: Exception) { e.printStackTrace() }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {},
                navigationIcon = {
                    TextButton(onClick = onBack) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ArrowBackIosNew, null, tint = Color(0xFF007AFF))
                            Text("Contactos", color = Color(0xFF007AFF), fontSize = 17.sp)
                        }
                    }
                },
                actions = {
                    TextButton(onClick = onEditClick) { Text("Editar", color = Color(0xFF007AFF), fontSize = 17.sp) }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFFF2F2F7))
            )
        },
        containerColor = Color(0xFFF2F2F7)
    ) { padding ->
        if (contact != null) {
            val safeContact = contact!!
            val imageUrl = safeContact.image?.url?.let { url ->
                if (url.contains("127.0.0.1")) url.replace("127.0.0.1", "10.0.2.2")
                else if (url.startsWith("http")) url
                else "http://10.0.2.2:8000$url"
            }

            Column(
                modifier = Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(10.dp))
                AsyncImage(
                    model = imageUrl ?: "https://ui-avatars.com/api/?name=${safeContact.name}",
                    contentDescription = null, contentScale = ContentScale.Crop,
                    modifier = Modifier.size(100.dp).clip(CircleShape).background(Color.Gray)
                )
                Spacer(Modifier.height(12.dp))
                Text(safeContact.name, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text("Detalles del contacto", fontSize = 14.sp, color = Color.Gray)
                Spacer(Modifier.height(24.dp))

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    IosActionButton(Icons.Filled.Message, "Mensaje") { scope.launch { snackbarHostState.showSnackbar("Mensaje para ${safeContact.name}") } }
                    IosActionButton(Icons.Filled.Phone, "Llamar") { scope.launch { snackbarHostState.showSnackbar("Llamando a ${safeContact.phone}") } }
                    IosActionButton(Icons.Filled.Videocam, "Video") { scope.launch { snackbarHostState.showSnackbar("Video con ${safeContact.name}") } }
                    IosActionButton(Icons.Filled.Email, "Correo") { scope.launch { snackbarHostState.showSnackbar("Correo a ${safeContact.email}") } }
                }

                Spacer(Modifier.height(24.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("móvil", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Text(safeContact.phone ?: "--", color = Color(0xFF007AFF), fontSize = 16.sp)
                        HorizontalDivider(Modifier.padding(vertical = 12.dp), thickness = 0.5.dp, color = Color.LightGray)
                        Text("correo electrónico", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Text(safeContact.email ?: "--", color = Color(0xFF007AFF), fontSize = 16.sp)
                    }
                }
                Spacer(Modifier.height(24.dp))
                Button(
                    onClick = {
                        scope.launch {
                            try {
                                RetrofitClient.api.deleteContact(safeContact.id)
                                Toast.makeText(context, "Eliminado", Toast.LENGTH_SHORT).show()
                                onBack()
                            } catch (e: Exception) { Toast.makeText(context, "Error", Toast.LENGTH_SHORT).show() }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                    shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().height(50.dp)
                ) { Text("Eliminar Contacto", color = Color.Red, fontSize = 16.sp) }
            }
        } else { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }
    }
}

@Composable
fun IosActionButton(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Surface(onClick = onClick, shape = RoundedCornerShape(12.dp), color = Color.White, shadowElevation = 1.dp, modifier = Modifier.size(65.dp)) {
            Box(contentAlignment = Alignment.Center) { Icon(icon, null, tint = Color(0xFF007AFF), modifier = Modifier.size(28.dp)) }
        }
        Spacer(Modifier.height(6.dp))
        Text(label, fontSize = 12.sp, color = Color(0xFF007AFF), fontWeight = FontWeight.Medium)
    }
}